-- MySQL dump 10.13  Distrib 8.0.22, for Linux (x86_64)
--
-- Host: localhost    Database: devest
-- ------------------------------------------------------
-- Server version	8.0.22-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `about_desc` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `term_desc` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `condation_desc` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `app_share_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `app_review_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `heeders`
--

DROP TABLE IF EXISTS `heeders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `heeders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heeders`
--

LOCK TABLES `heeders` WRITE;
/*!40000 ALTER TABLE `heeders` DISABLE KEYS */;
INSERT INTO `heeders` VALUES (1,'شركة تطوير برمجيات وحلول تقنية مخصصة','ديفيست هي شركة تجمع ريادي الأعمال المبدعين والذين أسسوا وساعدوا في بناء مشاريع رائدة في الشرق الأوسط.. واثقون بأننا نصنع المستقبل من خلال تمكين روّاد الأعمال لبناء شركات رائدة في هذه المنطقة من العالم.','2020-12-12 20:37:19','2020-12-12 23:06:59',NULL);
/*!40000 ALTER TABLE `heeders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `in_fo_about_companies`
--

DROP TABLE IF EXISTS `in_fo_about_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `in_fo_about_companies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `sub_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `who_are_we_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_who_are_we` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_who_are_we` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `how_we_work_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_how_we_work` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_how_we_work` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_fo_about_companies`
--

LOCK TABLES `in_fo_about_companies` WRITE;
/*!40000 ALTER TABLE `in_fo_about_companies` DISABLE KEYS */;
INSERT INTO `in_fo_about_companies` VALUES (5,'معلومات وتفاصيل عن الشركة وآلية عملها وأهدافها','معلومات عن الشركة','من نحن؟','ديفيست هي شركة استشارات إدارية تقوم بتمكين العملاء لدخول لعبة مستقبلهم الرقمي، من خلال خبرتنا وفريق عملنا المتكامل، نحن نجمع بين الخبرات المحلية والعالمية لنضمن وجودنا دائمًا بجانبك وأنت تقوم بعمل تحويل شامل لأعمالك. إذ نحن المؤسسة التي ستجعل استثمارات مشروعك في أمان هنا ستجد الطموح يلتقي بالابتكار، وستجد المستحيل يتحول إلى حقيقة، والغريب يتحول إلى شيء مألوف يلمس الواقع الخاص بك نحن من سنحول فكرتك إلى حقيقة ناجحة وملموسة.','about/TOgrlacWE8HbTDQRvu1SY0vEt5TAzytWjUHfPgKi.png','قيمنا:','قيمنا: -العالم يتغير بأشخاص ملهمين. -التطور المستمر هو أساس الريادة.                     -الفريق المبدع يصنع نتائج استثنائية. -الابتكار والتفكير خارج الصندوق؛ يجعلك تسبق الجميع.','about/cQzh5r1MDQmI4aE46HAa20ILYvaL44QtVTFRlhkN.png','2020-12-12 20:44:29','2020-12-21 23:13:14',NULL);
/*!40000 ALTER TABLE `in_fo_about_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_11_11_101723_create_app_settings_table',1),(5,'2020_12_12_172556_create_heeders_table',1),(6,'2020_12_12_173705_create_in_fo_about_companies_table',1),(7,'2020_12_12_175059_create_our_services_table',1),(8,'2020_12_12_200053_create_our_projects_table',2),(9,'2020_12_12_202125_create_prants_table',3),(10,'2020_12_12_203827_create_orders_table',4),(11,'2020_12_12_205038_create_settings_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (6,'Sief Hesham','backend.devest@outlook.sa','خدمات تطوير تطبيقات الأعمال','01013936641','السلام عليكم و رحمة الله وب ركاته برجاء التواصل معي الان حتي اطلب الحدمةا لتالية','2020-12-14 15:57:41','2020-12-14 15:57:41',NULL),(7,'Halim','halim-b@outlook.com','sdsdfsdf','2104240420','424242fdgsdgsdgsdgsdgsdgsdgsdgsdg','2020-12-21 10:51:58','2020-12-21 10:51:58',NULL),(8,'ecxec','tgdfs@fg.com','rcfcr','01000900534','sxwecdexexcercrtvfgvrtvfv','2020-12-22 14:56:41','2020-12-22 14:56:41',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `our_projects`
--

DROP TABLE IF EXISTS `our_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `our_projects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `cover` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `our_projects`
--

LOCK TABLES `our_projects` WRITE;
/*!40000 ALTER TABLE `our_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `our_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `our_services`
--

DROP TABLE IF EXISTS `our_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `our_services` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `section_icon` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_hidden` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `our_services`
--

LOCK TABLES `our_services` WRITE;
/*!40000 ALTER TABLE `our_services` DISABLE KEYS */;
INSERT INTO `our_services` VALUES (1,'fas fa-rocket fa-3x','التطوير البرمجي','نقدم لك المنتجات البرمجية بالطريقة التي تريدها, وننشئ لك منتجات رقمية تساعدك في اجتياز كل المشكلات التي ستواجهك في اللعبة الرقمية.','نصمم لك المشروع الرقمي الذي يناسب شركتك كما نساعدك على إيجاد حلول برمجية مناسبة لإنقاذ مشروعك،','2020-12-12 21:06:50','2020-12-14 14:52:56','2020-12-12 21:12:21'),(2,'fas fa-rocket fa-3x','خدمات تطوير تطبيقات الأعمال','نقوم بإنشاء تطبيقات للشركات بالتعاون مع مالكيها ونهدف إلى تحقيق غاية وهدف عملائنا بشكل كامل، احتياجاتك، ومتطلباتك ونواياك هي ما يهمنا في عملية تطوير تطبيقات الأعمال.',NULL,'2020-12-12 21:09:57','2020-12-12 21:36:46',NULL),(3,'fas fa-tablet-alt fa-3x','تطوير تطبيقات الجوال','نقوم ببرمجة وتطوير جميع مشاريع الأجهزة الجوالة، بمختلف المقاييس والتعقيد بدءًا من تطبيقات الشركات إلى تطبيقات الجوال المستقلة.','سنساعدك للوصول إلى جمهور الجوال المناسب لك من الفكرة الأولية إلى تصميم المنتج النهائي، يوفر فريق التطوير بشركة ديفيست تطبيقات مخصصة للهاتف الجوال تلبي معاييرك وتساعد عملك على البقاء عل ى اتصال باللعبة الرقمية، ومع مستوى الابتكار والجودة الذي نضعه في كل تطبيق من تطبيقاتنا يمكننا تعزيز علاقتك بعميلك، وتحسين تجربة المستخدم الشاملة على أجهزتهم الجوالة','2020-12-12 21:13:34','2020-12-12 21:35:01',NULL),(4,'fas fa-shopping-basket  fa-3x','برمجة المواقع والمتاجر الالكترونية','أطلق عنان مشروعك أو تجارتك لقوة الويب، اترك معنا أفضل أول انطباع لدى عميلك سنجعلك تظهر بشكل محترف على شاشة الكومبيوتر،','حيث نقوم بمواءمة مواهب وخبرات فريق ديفيست لإنشاء مواقع ومتاجر الكترونية تفاعلية فريدة من نوعها لتلبية أهداف عملك، حيث نقوم بمزج أفكار التصميم المبتكرة مع المفاهيم المعترف بها على نطاق واسع، ديفيست ستجعلك سيد اللعبة وستجعل منتجاتك وخدماتك متاحة للملايين.','2020-12-12 21:14:23','2020-12-12 21:35:52',NULL),(5,'fas fa-copyright fa-3x','نصمم هوية تجارية كاملة لك','نقوم بتصميم العلامات التجارية للشركات بعناية لأن علامتك التجارية هي الانطباع الذي تتركه شركتك في أذهان عملائك الحاليين والمحتملين والموظفين أيضًا،','ولأنها توضح رؤيتك، هويتك، وأهدافك. تساعد ديفيست الشركات على الظهور لعملائها بأفضل هوية بصرية ممكنة ولأجل ذلك لدينا فريق عمل مختص ومحترف من المصممين لنجعلك تظهر بأفضل شكل ممكن لنجعلك تتميز بين منافسينك في اللعبة الرقمية.','2020-12-12 21:16:01','2020-12-12 21:33:48',NULL),(6,'fas fa-users fa-3x','التسويق عبر مواقع التواصل الاجتماعي','لتحقيق أهدافك التجارية، نساعدك في التسويق عبر مواقع التواصل الاجتماعي عن طريق: -اعداد خططك التسويقية بشكل متكامل','-نحلل منافسينك -نصل لأفضل عملائك المحتملين عن طريق جمهور مستهدف مناسب لعملك -نصمم لك تصميمات مبتكرة -ندير حملاتك الإعلانية الممولة بشكل كامل، ونحلل نتائجها بشكل دوري -نكتب المحتوى المناسب لجمهورك المستهدف','2020-12-12 21:17:31','2020-12-12 21:36:26',NULL);
/*!40000 ALTER TABLE `our_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prants`
--

DROP TABLE IF EXISTS `prants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prants` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prants`
--

LOCK TABLES `prants` WRITE;
/*!40000 ALTER TABLE `prants` DISABLE KEYS */;
INSERT INTO `prants` VALUES (53,'prants/Bd04oyo5x8SWfUVGill5BtHMPtSgXcdJbAfJiB8e.png','2020-12-19 11:17:10','2020-12-19 11:17:10',NULL),(54,'prants/YJudjqPKWEHz0NjW07G9cF1bVkNTq2Hm9hdn9xEj.png','2020-12-19 11:17:33','2020-12-19 11:17:33',NULL),(55,'prants/GcHQ0ukGHH3AiExnQjavJ418ukdUXj5cHpQrxe5Q.png','2020-12-19 11:17:39','2020-12-19 11:17:39',NULL),(56,'prants/yzO7gbV7GxRBZ9xA5Zo90BDDJHc04V4QwfaUjqL4.png','2020-12-19 11:17:47','2020-12-19 11:17:47',NULL),(57,'prants/ZJ673jhkxTs57QkA0TwRRuitsSTAVdq5V7Be6Fl0.png','2020-12-19 11:17:53','2020-12-19 11:17:53',NULL),(58,'prants/8sNNuYAsBlmQpfjtKJV18Gghl17MABg1ulDzjGIP.png','2020-12-19 11:17:59','2020-12-19 11:17:59',NULL),(59,'prants/HoNNP3ezEB0NjHJK1ErsN5287KqTfPwujBZHqwXJ.png','2020-12-19 11:18:05','2020-12-19 11:18:05',NULL),(61,'prants/18fE8mInQke5sIAsu2U420vsAVx1CCFiCFN8KBst.png','2020-12-19 11:18:56','2020-12-19 11:18:56',NULL),(62,'prants/5YLPmlFO5hAKaNI14H7OZqAKensemuuU9aRRrRh2.png','2020-12-19 11:19:03','2020-12-19 11:19:03',NULL),(63,'prants/DLWQKlw3r78fsFkMD10vuANDJVrIet5Ir7eA6vV8.png','2020-12-19 11:19:09','2020-12-19 11:19:09',NULL),(64,'prants/o2J8Ys9mxKpFeUuzGdzHWZDABS6y58MkoGUtlhH6.png','2020-12-19 11:19:19','2020-12-19 11:19:19',NULL),(65,'prants/nzDk5v27vDDAKfd8oGBamuXmK1ttuhCoG5U0roZT.png','2020-12-19 11:19:24','2020-12-19 11:19:24',NULL);
/*!40000 ALTER TABLE `prants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `facebook_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `insta_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description_on_footer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'https://www.facebook.com/DevestCompany','https://twitter.com/DevestCompany','https://www.instagram.com/devestcompany/','info@devest.com','00201000009467','ديفيست هي شركة تجمع ريادي الأعمال المبدعين والذين أسسوا وساعدوا في بناء مشاريع رائدة في الشرق الأوسط.. واثقون بأننا نصنع المستقبل من خلال تمكين روّاد الأعمال لبناء شركات رائدة في هذه المنطقة من العالم.','2020-12-12 22:40:07','2020-12-22 13:04:40',NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_verified` enum('true','false') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('user','moderator','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_phone_unique` (`phone`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super Admin','01158344036',NULL,'$2y$10$Zog06u1rfx6liWgGaulJJeqKaFS3cYAvin0J6ROrl.8egg6RUvJTG','admin','admin@admin',NULL,NULL,'2020-12-12 17:54:31','2020-12-19 12:15:47'),(3,'E R R O R','01013936641',NULL,'$2y$10$PEda4rT6kZVoSVTVsHOxqezBBwUONKHQPZmVAzhM0.g9KkafskbQS','admin','dev.sief.hesham@gmail.com',NULL,NULL,'2020-12-14 15:23:18','2020-12-28 13:17:43'),(4,'Mohamed Ads','01000009467',NULL,'$2y$10$8vwP6pHEk8iOZLmcntnO5OqmJOkqo64rwZ1Dl4vny078qXToFtt/K','moderator','me@mhdads.com',NULL,NULL,'2020-12-14 15:46:42','2020-12-14 15:46:42'),(6,'test','78622008618',NULL,'$2y$10$MCNKURatw3gre7cpbqI8n.29pnywVVM7VLtJ1wC2yFSOULboqKSza','admin','pentester13377@gmail.com',NULL,NULL,'2021-01-01 11:38:54','2021-01-01 11:38:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-05 13:26:07
